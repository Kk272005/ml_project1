import { useEffect, useRef, useState } from 'react';
import { uploadFrame } from '../services/api';

function dataURLtoBlob(dataURL) {
  const arr = dataURL.split(',');
  const mime = arr[0].match(/:(.*?);/)[1];
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new Blob([u8arr], { type: mime });
}

export default function CameraFeed({ onDetection }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [isDetecting, setIsDetecting] = useState(false);
  const [error, setError] = useState('');
  const [lastResult, setLastResult] = useState(null);
  const [recent, setRecent] = useState([]);
  const [intervalMs, setIntervalMs] = useState(1500);

  useEffect(() => {
    return () => {
      const stream = videoRef.current?.srcObject;
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  const startCamera = async () => {
    setError('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setIsStreaming(true);
      }
    } catch (e) {
      setError('Unable to access camera. Please allow permissions.');
    }
  };

  const stopCamera = () => {
    const stream = videoRef.current?.srcObject;
    if (stream) {
      stream.getTracks().forEach((t) => t.stop());
    }
    setIsStreaming(false);
    setIsDetecting(false);
  };

  const captureAndSendFrame = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    const blob = dataURLtoBlob(dataUrl);
    const file = new File([blob], `frame_${Date.now()}.jpg`, { type: 'image/jpeg' });
    try {
      const res = await uploadFrame(file);
      setLastResult(res);
      if (res?.violationDetected) {
        setRecent((prev) => [{
          id: Date.now(),
          type: res.type,
          confidence: res.confidence,
          time: res.timestamp || new Date().toISOString(),
          imagePath: res.imagePath,
        }, ...prev].slice(0, 5));
      }
      if (onDetection) onDetection(res);
    } catch (e) {
      // ignore occasional network errors to keep stream running
    }
  };

  const startDetection = () => {
    if (!isStreaming) return;
    setIsDetecting(true);
  };

  useEffect(() => {
    if (!isDetecting) return;
    const interval = setInterval(captureAndSendFrame, Math.max(800, intervalMs));
    return () => clearInterval(interval);
  }, [isDetecting, intervalMs]);

  return (
    <div className="w-full max-w-6xl mx-auto p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className={`inline-flex h-2.5 w-2.5 rounded-full ${isDetecting ? 'bg-red-500 animate-pulse' : 'bg-gray-400'}`}></span>
          <span className="text-sm text-gray-700">{isDetecting ? 'Live detection running' : isStreaming ? 'Camera ready' : 'Camera stopped'}</span>
        </div>
        {isStreaming && (
          <div className="flex items-center gap-2 text-sm">
            <label className="text-gray-600">Interval</label>
            <select value={intervalMs} onChange={(e)=>setIntervalMs(Number(e.target.value))} className="border rounded px-2 py-1">
              <option value={800}>0.8s</option>
              <option value={1200}>1.2s</option>
              <option value={1500}>1.5s</option>
              <option value={2000}>2.0s</option>
              <option value={3000}>3.0s</option>
            </select>
          </div>
        )}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <div className="rounded-lg overflow-hidden bg-black aspect-video">
            <video ref={videoRef} className="w-full h-full object-contain" playsInline muted />
          </div>
          <div className="flex gap-2 mt-4">
            {!isStreaming ? (
              <button onClick={startCamera} className="px-4 py-2 bg-green-600 text-white rounded">Start Camera</button>
            ) : (
              <>
                <button onClick={stopCamera} className="px-4 py-2 bg-gray-700 text-white rounded">Stop Camera</button>
                <button onClick={startDetection} disabled={isDetecting} className="px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50">{isDetecting ? 'Detecting...' : 'Start Detection'}</button>
              </>
            )}
          </div>
          {error && <p className="text-red-600 mt-2">{error}</p>}
        </div>
        <div className="lg:col-span-1">
          <div className="border rounded p-3 bg-white">
            <div className="font-semibold mb-2">Latest result</div>
            {lastResult ? (
              <div className="text-sm">
                <div className="mb-1">Detected: {lastResult.violationDetected ? 'Yes' : 'No'}</div>
                {lastResult.type && <div className="mb-1">Type: {lastResult.type}</div>}
                {typeof lastResult.confidence === 'number' && <div className="mb-1">Confidence: {(lastResult.confidence*100).toFixed(1)}%</div>}
                {lastResult.imagePath && (
                  <img src={(import.meta.env.VITE_API_BASE || 'http://127.0.0.1:4000') + lastResult.imagePath} alt="last" className="mt-2 rounded border" />
                )}
              </div>
            ) : (
              <div className="text-sm text-gray-600">No results yet.</div>
            )}
          </div>
          <div className="mt-3 border rounded p-3 bg-white">
            <div className="font-semibold mb-2">Recent violations</div>
            <ul className="space-y-2 max-h-64 overflow-auto text-sm">
              {recent.length === 0 && <li className="text-gray-600">None yet</li>}
              {recent.map(r => (
                <li key={r.id} className="flex items-center gap-2">
                  <span className="inline-block w-2 h-2 bg-red-500 rounded-full" />
                  <div className="flex-1">
                    <div className="font-medium">{r.type}</div>
                    <div className="text-gray-600 text-xs">{new Date(r.time).toLocaleTimeString()}</div>
                  </div>
                  {r.imagePath && <img src={(import.meta.env.VITE_API_BASE || 'http://127.0.0.1:4000') + r.imagePath} alt="thumb" className="w-10 h-10 object-cover rounded" />}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}




