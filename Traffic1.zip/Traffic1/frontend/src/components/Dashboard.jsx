import { useEffect, useMemo, useState } from 'react';
import { listViolations, deleteViolation } from '../services/api';
import ViolationCard from './ViolationCard';

export default function Dashboard() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [type, setType] = useState('');
  const [query, setQuery] = useState('');
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [preview, setPreview] = useState(null);

  async function load() {
    setLoading(true);
    try {
      const data = await listViolations({ type: type || undefined, start: start || undefined, end: end || undefined });
      setItems(data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function onDelete(id) {
    await deleteViolation(id);
    load();
  }

  const apiBase = (import.meta.env.VITE_API_BASE || 'http://127.0.0.1:4000');
  const filtered = useMemo(() => {
    return items.filter(v => {
      const matchType = type ? v.type === type : true;
      const q = query.trim().toLowerCase();
      const matchQuery = q ? ((v.type||'').toLowerCase().includes(q) || (v.location||'').toLowerCase().includes(q)) : true;
      return matchType && matchQuery;
    });
  }, [items, type, query]);

  return (
    <div className="p-4">
      <div className="flex flex-col md:flex-row md:items-end gap-3 mb-4">
        <div className="flex-1">
          <label className="block text-sm">Search</label>
          <input value={query} onChange={(e)=>setQuery(e.target.value)} className="border px-2 py-1 rounded w-full" placeholder="Type or location" />
        </div>
        <div>
          <label className="block text-sm">Type</label>
          <select value={type} onChange={(e)=>setType(e.target.value)} className="border px-2 py-1 rounded">
            <option value="">All</option>
            <option value="Helmet Violation">Helmet Violation</option>
            <option value="Seatbelt Violation">Seatbelt Violation</option>
            <option value="Signal Jumping">Signal Jumping</option>
            <option value="General Violation">General Violation</option>
          </select>
        </div>
        <div>
          <label className="block text-sm">Start</label>
          <input type="datetime-local" value={start} onChange={(e) => setStart(e.target.value)} className="border px-2 py-1 rounded" />
        </div>
        <div>
          <label className="block text-sm">End</label>
          <input type="datetime-local" value={end} onChange={(e) => setEnd(e.target.value)} className="border px-2 py-1 rounded" />
        </div>
        <button onClick={load} className="bg-blue-600 text-white px-4 py-2 rounded">Apply</button>
        <a href={apiBase + '/api/violations/export/csv'} className="bg-green-600 text-white px-4 py-2 rounded">Export CSV</a>
      </div>
      {loading ? (
        <div>Loading...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((v) => (
            <div key={v._id} onClick={()=>setPreview(v)} className="cursor-pointer">
              <ViolationCard item={v} apiBase={apiBase} onDelete={onDelete} />
            </div>
          ))}
        </div>
      )}
      {preview && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4" onClick={()=>setPreview(null)}>
          <div className="bg-white rounded shadow max-w-3xl w-full overflow-hidden" onClick={(e)=>e.stopPropagation()}>
            <img src={apiBase + preview.imageURL} alt={preview.type} className="w-full max-h-[70vh] object-contain bg-black" />
            <div className="p-3 text-sm">
              <div className="font-semibold">{preview.type}</div>
              <div>Time: {new Date(preview.time).toLocaleString()}</div>
              {preview.location && <div>Location: {preview.location}</div>}
              {preview.confidence != null && <div>Confidence: {(preview.confidence * 100).toFixed(1)}%</div>}
              <div className="mt-2 flex justify-end gap-2">
                <button onClick={()=>onDelete(preview._id)} className="text-red-600">Delete</button>
                <button onClick={()=>setPreview(null)} className="px-3 py-1 bg-gray-200 rounded">Close</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
