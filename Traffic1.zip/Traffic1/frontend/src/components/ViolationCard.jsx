export default function ViolationCard({ item, apiBase, onDelete }) {
  return (
    <div className="border rounded overflow-hidden shadow-sm">
      <img src={apiBase + item.imageURL} alt={item.type} className="w-full h-48 object-cover" />
      <div className="p-3 text-sm">
        <div className="font-semibold">{item.type}</div>
        <div>Time: {new Date(item.time).toLocaleString()}</div>
        {item.location && <div>Location: {item.location}</div>}
        {item.confidence != null && <div>Confidence: {(item.confidence * 100).toFixed(1)}%</div>}
        <button onClick={() => onDelete(item._id)} className="mt-2 text-red-600">Delete</button>
      </div>
    </div>
  );
}
