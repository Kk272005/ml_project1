import { useState } from 'react';
import Dashboard from './components/Dashboard';
import CameraFeed from './components/CameraFeed';

export default function App() {
  const [tab, setTab] = useState('camera');

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="max-w-6xl mx-auto p-4 flex items-center justify-between">
          <h1 className="text-xl font-semibold">Smart Traffic Management</h1>
          <nav className="flex gap-2">
            <button onClick={() => setTab('camera')} className={`px-3 py-1 rounded ${tab==='camera'?'bg-blue-600 text-white':'bg-gray-200'}`}>Camera</button>
            <button onClick={() => setTab('dashboard')} className={`px-3 py-1 rounded ${tab==='dashboard'?'bg-blue-600 text-white':'bg-gray-200'}`}>Dashboard</button>
          </nav>
        </div>
      </header>
      <main className="max-w-6xl mx-auto p-4">
        {tab === 'camera' ? <CameraFeed /> : <Dashboard />}
      </main>
    </div>
  );
}


