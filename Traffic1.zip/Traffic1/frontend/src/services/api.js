import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:4000';

export const api = axios.create({
  baseURL: API_BASE,
});

export async function uploadFrame(fileOrFormData) {
  let formData;
  if (fileOrFormData instanceof FormData) {
    formData = fileOrFormData;
  } else {
    formData = new FormData();
    formData.append('frame', fileOrFormData);
  }
  const { data } = await api.post('/api/upload', formData);
  return data;
}

export async function listViolations(params = {}) {
  const { data } = await api.get('/api/violations', { params });
  return data;
}

export async function deleteViolation(id) {
  const { data } = await api.delete(`/api/violations/${id}`);
  return data;
}

export async function login(email, password) {
  const { data } = await api.post('/api/auth/login', { email, password });
  return data;
}

import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000';

export async function uploadFrame(file) {
  const form = new FormData();
  form.append('frame', file);
  const res = await axios.post(`${API_BASE}/api/upload`, form, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return res.data;
}

export async function fetchViolations() {
  const res = await axios.get(`${API_BASE}/api/violations`);
  return res.data;
}

export async function deleteViolation(id) {
  const res = await axios.delete(`${API_BASE}/api/violations/${id}`);
  return res.data;
}

export function exportViolationsCsv(rows) {
  if (!rows?.length) return;
  const header = ['type','confidence','time','location','imageURL'];
  const lines = [header.join(',')].concat(
    rows.map(r => [r.type, r.confidence, r.time, r.location||'', r.imageURL].map(x => `"${String(x??'').replaceAll('"','""')}"`).join(','))
  );
  const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `violations_${Date.now()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}



