const Violation = require('../models/Violation');
const { Parser } = require('json2csv');

async function listViolations(req, res) {
    try {
        const { type, start, end } = req.query;
        const filter = {};
        if (type) filter.type = type;
        if (start || end) {
            filter.time = {};
            if (start) filter.time.$gte = new Date(start);
            if (end) filter.time.$lte = new Date(end);
        }
        const items = await Violation.find(filter).sort({ time: -1 });
        res.json(items);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch violations' });
    }
}

async function getViolation(req, res) {
    try {
        const item = await Violation.findById(req.params.id);
        if (!item) return res.status(404).json({ error: 'Not found' });
        res.json(item);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch violation' });
    }
}

async function deleteViolation(req, res) {
    try {
        const item = await Violation.findByIdAndDelete(req.params.id);
        if (!item) return res.status(404).json({ error: 'Not found' });
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to delete violation' });
    }
}

async function createViolation(req, res) {
    try {
        const created = await Violation.create(req.body);
        res.status(201).json(created);
    } catch (err) {
        res.status(400).json({ error: 'Failed to create violation' });
    }
}

async function exportCsv(req, res) {
    try {
        const items = await Violation.find({}).sort({ time: -1 }).lean();
        const parser = new Parser({ fields: ['_id', 'type', 'time', 'confidence', 'location', 'imageURL'] });
        const csv = parser.parse(items);
        res.header('Content-Type', 'text/csv');
        res.attachment('violations.csv');
        return res.send(csv);
    } catch (err) {
        res.status(500).json({ error: 'Failed to export CSV' });
    }
}

module.exports = {
    listViolations,
    getViolation,
    deleteViolation,
    createViolation,
    exportCsv,
};


