const mongoose = require('mongoose');

const ViolationSchema = new mongoose.Schema(
    {
        imageURL: { type: String, required: true },
        type: { type: String, required: true },
        time: { type: Date, required: true },
        confidence: { type: Number, default: null },
        location: { type: String, default: null },
        meta: { type: Object, default: {} },
    },
    { timestamps: true }
);

module.exports = mongoose.model('Violation', ViolationSchema);

const mongoose = require('mongoose');

const ViolationSchema = new mongoose.Schema(
    {
        imageURL: { type: String, required: true },
        type: { type: String, required: true },
        time: { type: Date, required: true },
        confidence: { type: Number },
        location: { type: String },
        meta: { type: Object, default: {} },
    },
    { timestamps: true }
);

module.exports = mongoose.model('Violation', ViolationSchema);



