const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const axios = require('axios');
const mongoose = require('mongoose');
require('dotenv').config();

const connectDB = require('./config/db');
const violationRoutes = require('./routes/violations');
const Violation = require('./models/Violation');

const app = express();

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(morgan('dev'));

// Static folder for uploaded images
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}
app.use('/uploads', express.static(uploadsDir));

// Multer storage setup
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadsDir);
    },
    filename: function (req, file, cb) {
        const timestamp = Date.now();
        const ext = path.extname(file.originalname || '.jpg');
        cb(null, `frame_${timestamp}${ext}`);
    },
});
const upload = multer({ storage });

// Health
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', service: 'backend', time: new Date().toISOString() });
});

// Upload endpoint → forwards to AI engine → saves record if violation
app.post('/api/upload', upload.single('frame'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No frame uploaded' });
        }

        const aiUrl = process.env.AI_ENGINE_URL || 'http://127.0.0.1:5001/analyze';

        // Send image to AI engine
        const formData = new (require('form-data'))();
        formData.append('image', fs.createReadStream(req.file.path), {
            filename: path.basename(req.file.path),
        });

        const aiResponse = await axios.post(aiUrl, formData, {
            headers: formData.getHeaders(),
            timeout: 20000,
        });

        const result = aiResponse.data || {};

        // Persist if violation detected
        let saved = null;
        if (result.violationDetected) {
            saved = await Violation.create({
                imageURL: `/uploads/${path.basename(req.file.path)}`,
                type: result.type || 'Unknown',
                time: result.timestamp ? new Date(result.timestamp) : new Date(),
                confidence: result.confidence ?? null,
                location: result.location || null,
                meta: result.meta || {},
            });
        }

        res.json({
            ...result,
            imagePath: `/uploads/${path.basename(req.file.path)}`,
            record: saved,
        });
    } catch (err) {
        console.error('Upload error:', err.message);
        return res.status(500).json({ error: 'AI engine error or internal error' });
    }
});

// Violations REST
app.use('/api/violations', violationRoutes);

// Optional auth (simple demo JWT)
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// Demo admin user from env or defaults
const DEMO_ADMIN_USER = process.env.ADMIN_USER || 'admin@example.com';
const DEMO_ADMIN_PASS = process.env.ADMIN_PASS || 'admin123';
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';

app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body || {};
    const isMatch = email === DEMO_ADMIN_USER && password === DEMO_ADMIN_PASS;
    if (!isMatch) return res.status(401).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ sub: email, role: 'admin' }, JWT_SECRET, { expiresIn: '8h' });
    res.json({ token });
});

// Start server
const PORT = process.env.PORT || 4000;
connectDB()
    .then(() => {
        app.listen(PORT, () => console.log(`Backend listening on :${PORT}`));
    })
    .catch((err) => {
        console.error('DB connection failed:', err.message);
        process.exit(1);
    });



