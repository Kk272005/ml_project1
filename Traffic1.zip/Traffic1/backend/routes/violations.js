const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/violationsController');

router.get('/', ctrl.listViolations);
router.get('/export/csv', ctrl.exportCsv);
router.get('/:id', ctrl.getViolation);
router.delete('/:id', ctrl.deleteViolation);
router.post('/', ctrl.createViolation);

module.exports = router;


