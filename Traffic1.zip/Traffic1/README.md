# Smart Traffic Management Website

End-to-end demo system: React frontend with webcam capture, Node/Express backend with MongoDB storage, and a Python Flask AI microservice that analyzes frames (YOLO-ready, demo mode by default). Violations are recorded with image, type, time, and confidence, and shown on a dashboard.

## Architecture

- Frontend: React + Vite + Tailwind
- Backend: Node.js + Express + Multer + MongoDB (Mongoose)
- AI Engine: Python + Flask + OpenCV (placeholder YOLO integration)

Flow:
1) Browser captures frames from webcam
2) POST to backend `/api/upload`
3) Backend forwards image to AI `POST /analyze`
4) AI returns detection result; backend stores violation if detected
5) Dashboard fetches and displays violations

## Prerequisites
- Node.js 18+
- Python 3.10+
- MongoDB running locally (`mongodb://127.0.0.1:27017`)

## Setup

### Backend
```
cd backend
npm install
```
Create `.env` (optional):
```
PORT=4000
MONGO_URI=mongodb://127.0.0.1:27017/traffic_management
AI_ENGINE_URL=http://127.0.0.1:5001/analyze
ADMIN_USER=admin@example.com
ADMIN_PASS=admin123
JWT_SECRET=change_me
```
Run:
```
npm run dev
```

### AI Engine
```
cd ai-engine
python -m venv .venv
. .venv/Scripts/activate  # Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
python detect.py
```
Health check: `GET http://127.0.0.1:5001/health`

### Frontend
```
cd frontend
npm install
npm run dev
```
Set base API in `.env` (optional):
```
VITE_API_BASE=http://127.0.0.1:4000
```

Open `http://127.0.0.1:5173` (default Vite port)

## Frontend Usage
- Go to Camera tab
- Allow camera access
- Start detection (button in `CameraFeed.jsx`) sends frames periodically to backend
- Open Dashboard to view violations, filter by type/date, export CSV

## API
- POST `/api/upload` multipart field `frame`: uploads one image; returns AI result and stored record if violation
- GET `/api/violations` [type, start, end]
- GET `/api/violations/:id`
- DELETE `/api/violations/:id`
- GET `/api/violations/export/csv`
- POST `/api/auth/login` → `{ token }` (demo)

## YOLO Integration (optional)
Replace demo logic in `ai-engine/detect.py` with actual model inference using `ultralytics`:
```python
from ultralytics import YOLO
model = YOLO('yolov8n.pt')
# Run inference and apply your violation logic
```

## Notes
- Images are stored locally under `backend/uploads/`
- For production, use S3/Cloudinary and secure auth/roles
- Add HTTPS and CORS restrictions for deployment


