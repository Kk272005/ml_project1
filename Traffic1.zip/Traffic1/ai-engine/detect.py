from flask import Flask, request, jsonify
from datetime import datetime
import os
import random

# Optional: import cv2, torch, ultralytics if available
try:
    import cv2  # type: ignore
except Exception:
    cv2 = None

app = Flask(__name__)

@app.get('/health')
def health():
    return jsonify({"status": "ok", "service": "ai-engine", "time": datetime.utcnow().isoformat()})


@app.post('/analyze')
def analyze():
    # In production, load a YOLOv8 model and run inference here
    # For demo, return randomized violation for uploaded image
    if 'image' not in request.files:
        return jsonify({"error": "image file required"}), 400

    image = request.files['image']
    # Save to temp folder if needed for visualization; backend already stores original
    # image.save(os.path.join('tmp', image.filename))

    # Demo logic: randomly flag a violation with some probability
    violation_types = [
        ("Helmet Violation", 0.9),
        ("Seatbelt Violation", 0.88),
        ("Signal Jumping", 0.92),
        ("No Violation", 0.99),
    ]
    choice = random.choices(violation_types, weights=[2, 2, 1, 5], k=1)[0]

    if choice[0] == 'No Violation':
        return jsonify({
            "violationDetected": False,
            "type": None,
            "confidence": 0.0,
            "timestamp": datetime.utcnow().isoformat() + 'Z',
        })

    return jsonify({
        "violationDetected": True,
        "type": choice[0],
        "confidence": choice[1],
        "timestamp": datetime.utcnow().isoformat() + 'Z',
        "meta": {"notes": "demo engine"}
    })


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5001))
    app.run(host='0.0.0.0', port=port, debug=True)


